var mathlib = require('./mathlib')();
console.log(mathlib.add(1,2))
console.log(mathlib.multiply(1,2))
