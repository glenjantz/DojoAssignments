//
//  Recipe+CoreDataClass.swift
//  recipies
//
//  Created by Glen Jantz on 3/23/17.
//  Copyright © 2017 Glen Jantz. All rights reserved.
//

import Foundation
import CoreData

@objc(Recipe)
public class Recipe: NSManagedObject {

}
