//
//  Contacts+CoreDataClass.swift
//  iOSExam
//
//  Created by Glen Jantz on 3/24/17.
//  Copyright © 2017 Glen Jantz. All rights reserved.
//

import Foundation
import CoreData

@objc(Contacts)
public class Contacts: NSManagedObject {

}
