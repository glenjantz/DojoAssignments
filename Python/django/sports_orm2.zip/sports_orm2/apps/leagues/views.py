from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

# def index(request):
# 	context = {
# 		"leagues": League.objects.all(),
# 		"teams": Team.objects.all(),
# 		"players": Player.objects.all(),
# 	}
# 	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")

# def index1(request):
# 	user = League.objects.filter(sport="Baseball")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index2(request):
# 	user = League.objects.filter(name__contains="Women")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index3(request):
# 	user = League.objects.filter(sport__contains="Hockey")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index4(request):
# 	user = League.objects.exclude(sport__contains="football")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index5(request):
# 	user = League.objects.filter(name__contains="conference")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index6(request):
# 	user = League.objects.filter(name__contains="Atlantic")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index7(request):
# 	user = Team.objects.filter(location="Dallas")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index8(request):
# 	user = Team.objects.filter(team_name="Raptors")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index9(request):
# 	user = Team.objects.filter(location__contains="City")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index10(request):
# 	user = Team.objects.filter(team_name__startswith="T")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index11(request):
# 	user = Team.objects.order_by("location")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index12(request):
# 	user = Team.objects.order_by("-team_name")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index13(request):
# 	user = Player.objects.filter(last_name="Cooper")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index14(request):
# 	user = Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index15(request):
# 	user = Player.objects.filter(first_name="Alexander")|Player.objects.filter(first_name="Wyatt")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Team.objects.filter(league__name="Atlantic Soccer Conference")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players":  Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index2(request):
# 	user = Player.objects.filter(curr_team__team_name="Penguins", curr_team__location="Boston")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players":  user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index3(request):
# 	user = Player.objects.filter(curr_team__league__name="International Collegiate Baseball Conference")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players":  user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index4(request):
# 	user = Player.objects.filter(curr_team__league__name="American Conference of Amateur Football", last_name="Lopez")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players":  user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index5(request):
# 	user = Player.objects.filter(curr_team__league__sport="Football")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players":  user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Team.objects.filter(curr_players__first_name="Sophia")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players":  Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = League.objects.filter(teams__curr_players__first_name="Sophia")
# 	context ={'leagues': user, 'teams': Team.objects.all(), "players":  Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Player.objects.filter(last_name="Flores").exclude(curr_team__location="Washington",curr_team__team_name="Roughriders")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players":  user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Player.objects.filter(all_teams__location="Manitoba",all_teams__team_name="Tiger-Cats")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Player.objects.filter(all_teams__location="Wichita",all_teams__team_name="Vikings").exclude(curr_team__location="Wichita",curr_team__team_name="Vikings")
# 	context ={'leagues': League.objects.all(), 'teams': Team.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Team.objects.filter(all_players__first_name="Jacob",all_players__last_name="Gray").exclude(location="Oregon",team_name="Colts")
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

# def index(request):
# 	user = Player.objects.filter(first_name="Joshua",all_teams__league__name="Atlantic Federation of Amateur Baseball Players")
# 	context ={'leagues': League.objects.all(), 'teams': League.objects.all(), "players": user
# 	}
# 	return render(request, "leagues/index.html", context)
#
# def index(request):
# 	user = Team.objects.annotate(count=Count('all_players')).filter(count__gte =12).order_by('id')
# 	context ={'leagues': League.objects.all(), 'teams': user, "players": Player.objects.all()
# 	}
# 	return render(request, "leagues/index.html", context)

def index(request):
    user = Player.objects.annotate(num_teams=Count('all_teams')).order_by('num_teams', 'id')
    context = {"players": user, "leagues": League.objects.all(), "teams": Team.objects.all(),}
    return render(request, "leagues/index.html", context)
