var mathlib = require('./mathlib')();
console.log(mathlib.add(1,2))
console.log(mathlib.multiply(1,2))
console.log(mathlib.square(5))
console.log(mathlib.random(20,2))
